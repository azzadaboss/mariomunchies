#!/usr/bin/env python3
"""
Super Mario Platformer Game - Main Entry
"""

import pygame
import sys
from game import Game

def main():
    pygame.init()

    try:
        pygame.mixer.init()
        print("Audio initialized successfully")
    except pygame.error as e:
        print(f"Audio init failed: {e} — running without sound")

    try:
        game = Game()
        game.run()
    except Exception as e:
        print(f"Unexpected error: {e}")
    finally:
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    main()
